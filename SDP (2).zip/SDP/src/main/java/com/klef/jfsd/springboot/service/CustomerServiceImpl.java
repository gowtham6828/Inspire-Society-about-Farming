package com.klef.jfsd.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.klef.jfsd.springboot.model.Customer;
import com.klef.jfsd.springboot.repository.CustomerRepository;
@Service
public class CustomerServiceImpl implements CustomerService{
	@Autowired
	private CustomerRepository customerRepository;

	@Override
    public String customerRegistration(Customer customer) {
        try {
            customerRepository.save(customer);
            return "Customer Registered Successfully";
        } catch (DataIntegrityViolationException e) {
            if (e.getMessage().contains("customer_table.UK63furrnm7cjsj6nmj4fm9cipm")) {
                return "Registration Failed: Email already exists";
            } else if (e.getMessage().contains("customer_table.UK_contact_constraint")) {
                return "Registration Failed: Contact number already exists";
            } else {
                return "Registration Failed: Data integrity violation";
            }
        } catch (Exception e) {
            return "Registration Failed: " + e.getMessage();
        }
    }
	@Override
	public Customer checkCustomerLogin(String email, String password) {
		// TODO Auto-generated method stub
		return customerRepository.checkCustomerLogin(email, password);
	}

}
